package com.example.mediaplayer;

import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView textView;
    TextView song;
    Button play;
    Button pause;
    Button forward;
    Button rewind;
    Button stop;
    Button restart;
    int starttime=0;
    int stoptime=0;
    int forwardtime=5000;
    int backwardtime=5000;
    MediaPlayer mediaPlayer,mediaPlayerNew;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mediaPlayer=MediaPlayer.create(this,R.values.song);
    }
}